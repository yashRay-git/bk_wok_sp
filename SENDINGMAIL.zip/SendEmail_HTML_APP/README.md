
<br>
	Refer these links for more details on this project <br>
		https://code2blog.wordpress.com/  <br>
		https://youtube.com/results?search_query=code2blog <br>
		
<pre>
	This iib project (SendEmail_V1_APP) sends email using smtp server and email output node
</pre>
